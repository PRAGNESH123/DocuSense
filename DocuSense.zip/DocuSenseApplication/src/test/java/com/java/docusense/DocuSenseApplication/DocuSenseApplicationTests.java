package com.java.docusense.DocuSenseApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocuSenseApplicationTests {

	@Test
	void contextLoads() {
	}

}
